5-9-98

================================================================

Model Name              : Bauul

installation directory  : quake2/baseq2/players/bauul

Author                  : Brian "EvilBastard" Collins

Email Address           : brian@zono.com

Website Address         : www.michaeljwolf.com/brian/quake.htm

Model description       : 

	Bauul is a big orange guy that likes flowers and frilly things.
        He usually spends his time writing poetry or terrorizing the 
        local villagers.

Other info              : 
	Bauul's skin frame was created entirely in Q2modeler. I love that
	program. I don't know what i did before it. I tried to optimize
	the skin as much as possible, but i think i did so at the expense
	of all you skinners out there. You will see the skin is all cut
	up like the regular Q2 male model. I also hope someone does some
	better ctf skins, mine are quite bad.

Additional Credits to   : 
	* Idsoftware 
	* Q2modeler


Thanks to               :

	* Winter (you know, from Winter's faerie) For the inspiration, and 
	great ideas. 
	* All you bodyshop guys (and girls when applicable).
	

================================================================

* Play Information *

New Sounds              : NO

CTF Skins               : YES

VWEP Support            : Yes, but all the weapons will look the same.
			  At least no diaper effect though.


* Construction *

Poly Count              : 557 tris.md2 / 71 weapon.md2

Vert Count              : 295 tris.md2 / 43 weapon.md2

Skin Count              : 1 DM, 2 CTF

Base		        : None. This model was made as a base for my
			  next run of male models.

Editor used             : 
		Modeling - lightwave	
		Animation- lightwave + puppetmaster
		Skining  - Q2modeler
		Painting - Photoshop, NST
		
Known Bugs              : None that i know of.

Build/Animation time    : about 20 hours total over 2 weeks.

* Copyright / Permissions *
QUAKE(R) and QUAKE II(R) are registered trademarks of id Software, Inc.
Feel free to edit my model as you see fit, just be sure to mention me
in the readme file. This model is not to be distributed as part of any
commercial product.
