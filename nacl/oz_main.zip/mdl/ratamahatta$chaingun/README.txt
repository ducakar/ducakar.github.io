11-02-98

================================================================

Model Name              : Ratamahatta

installation directory  : quake2/baseq2/players/Ratamahatta

Author                  : Brian "EvilBastard" Collins

additional skins by     :

	'Gearwhore'  by MrRogers
	'Jaws'       by Claudius Brunnecker

Email Address           : brian@zono.com

Website Address         : http://www.deviousassassins.com/EvilBastard/

Model description       : 

	It's been a long time in the making, but he's finaly done. This PPM is the prize of the Bodyshop Q2 tournament won by Tank Abbot. I hope he likes it  ;P

Model Info	        :
	Ratamahatta is a fun loving guy, who like to pull the wings off files, and similarly amusing things. After a long day of gratuitous destruction and rolling around in his own filth, Rat always enjoys a spot of tea.

Additional Credits to   : 
	
	* Idsoftware 
	* NST!!! Know it and love it

Thanks to               :

	Npherno and MrRogers for all the help
	Virus[DA] for hosting my website.
	Rogue13 and John McPherson for the advise and input.

================================================================

* Play Information *

New Sounds              : NO

CTF Skins               : YES

VWEP Support            : No


* Construction *

Poly Count              : 666 tris.md2 / 119 weapon.md2

Vert Count              : 344 tris.md2 / 85 weapon.md2

Skin Count              : 4 DM, 2 CTF

Base		        : Forgotten One

Editor used             : 
		Modeling - lightwave	
		Animation- lightwave + puppetmaster
		Skining  - NST 
		Painting - Photoshop, NST
		Viewing  - Skin View 
		
Known Bugs              : None that i know of.


* Copyright / Permissions *
QUAKE(R) and QUAKE II(R) are registered trademarks of id Software, Inc.
Feel free to edit my model as you see fit, just be sure to mention me
in the readme file. This model is not to be distributed as part of any
commercial product.
