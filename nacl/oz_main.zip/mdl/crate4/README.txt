--------------------------------
Free to use on freeware, shareware and commercial projects.
Credits are really appreciated ;-)
Not to be used or sold as part of any other model pack without my permission!!
Hope you find a use for em!!

Psionic
-----------------------------
Subject Re: permission to use game models  
From  Psionic <psionic@blueyonder.co.uk>  
Date Wednesday, June 21, 2006 9:37 am 
To mitaman1@optonline.net 


Feel free to use the models in your projects!!
and thanks for the credits, much appreciated ;-)

Psi

mitaman1@optonline.net wrote:
SCI-FI Prefab pack - Psionic 2005
psionic@blueyonder.co.uk <mailto:psionic@blueyonder.co.uk>

 
06-21-06
 
Hello Psionic,
 
My name is Mike Poeschl (aka MitaMAN) and as a hobby I create maps for freeware First Person Shooters such as CUBE and SAUERBRATEN (cube2). You can find it here:
 
http://wouter.fov120.com/cube/
 
I am requesting permission to use several of your models from "SCI-FI Prefab pack" that I came across on this site:
 
http://www.psionic3d.co.uk/news.php
 
There is no commercial value to the games. Just a bunch of mappers, modelers, and programmers having fun. Of course full credit will be given to you in a "credits readme file".
 
Thanks for your time and consideration:
 
Mike Poeschl (MitaMAN)
 
 




