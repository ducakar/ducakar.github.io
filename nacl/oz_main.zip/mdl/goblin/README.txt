====================================================
 Goblin                               Conrad, 000112 
 Quake2/baseq2/players/goblin         Sweden/Malmoe.                 
====================================================
 
 Special guest star Rodrigo, made the:
 Cathos, deadburned, and warrior skins,
 Email: rodrigo@sport4u.com

 Model, anims and goblin skin,
 done by: Me, Conrad       
 Email: con@telia.com     

====================================================

MODEL DESCRIPTION:
A small monster, with a big axe.       

CONSTRUCTION:
Poly Count              : 578 polys
Vert Count              : 292 Verts
Skin Count              : 4 Skins
Base                    : New model
Editor used             : Imagine, Lightwave, Nst, Qdata, Paintshop
Known Bugs              : Any bugs
Build/Animation time    : 5 months? Lazy me,,

POOPS:
Some, But lost the source files and can't correct them.
Also due to the small size of the model it might be hard
to play with.

INSTALLATION:
Unzip the files into quake2/baseq2/players/

Don�t hesitate to send me a comment,
I aprechiate feedback.

QUAKE(R) and QUAKE II(R) are registered trademarks of id Software, Inc.
You can't use this model for anything other than gaming, Without asking me first.

