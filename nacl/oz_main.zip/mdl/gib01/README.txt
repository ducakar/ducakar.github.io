Description
===========
Files in this folder:

by "makkE"
Markus Bekel
e-mail: makk_e@web.de

===================================================================================================
These files have been licensed under a the
"Creative Commons Deed / Attribution Non-commercial Share-Alike ( at-nc-sa )" 
===================================================================================================

You are free:

    * to copy, distribute, display, and perform the work
    * to make derivative works

Under the following conditions:

"by" 	
     -Attribution. You must give the original author credit.
"nc"	
     -Non-Commercial. You may not use this work for commercial purposes.
"sa" 	
     -Share Alike. If you alter, transform, or build upon this work, you may distribute the resulting          work only under a licence identical to this one.

    * For any reuse or distribution, you must make clear to others the licence terms of this work.
    * Any of these conditions can be waived if you get permission from the copyright holder.

Your fair use and other rights are in no way affected by the above.

This is a human-readable summary of the Legal Code (the full licence).

=====================================================================================================

See:

http://creativecommons.org/licenses/by-nc-sa/2.5/deed.en_GB

for the original "human readable" document.

http://creativecommons.org/licenses/by-nc-sa/2.5/legalcode

for the full legal code. 

visit creativecommons.org for general information and translations of the above documents. 



