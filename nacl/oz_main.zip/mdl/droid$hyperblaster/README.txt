Model Name              : droid
installation directory  : quake2/baseq2/players/droid
Author                  : III_Demon
Email Address           : III_Demon@yahoo.com
Web Page		: http://www.drazium.com/3d/

* Description *

If you don't know what the battle droid is... nothing I can say will help. 
This model is my first released Q2 player model, and it just is what it is. A battle droid. A painfully obvious choice for a player model. 
I have created 7 skins: the 4 action figure variations (clean, dirty, blasted, and slashed), the commander - OOM-9, and CTF red and blue skins.
Anyone who wants to make skins for this model, email me and I'll be glad to send you the original photoshop file with layers and everything.
The id vweps have been converted for the droid, it would have been nice to make a set of starwars weapons, but I just cant see putting that much effort into it with Q3 right around the corner. Yes, I plan on making a battle droid for Q3.  =] 

* Tools	*

3dsmax, Q2 modeler, Npherno's skin tool, the 3dsmax .md2 exporter made by the guy on the skynet project whos url I cant find anymore =], photoshop, skinview,  probably something else I'm forgetting...

* How to use this model *

Unzip the contents of droid.zip into quake2/baseq2/players/droid

* Thanx *

id, George Lucas and ILM, A|W, Npherno, Phillip martin, the Q2PMP page, and anyone else who makes tools and models and maps and otherwise keeps the online game communities alive!

* Copyright / Permissions *

The battle droid design is of course (c) lucasfilm and I can't make any sort of claim to it, so feel free to use this however you want. If you use it in any sort of mod, TC, etc., please let me know just so I can see what people are doing with my model.
