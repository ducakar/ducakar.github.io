Title:          OpenZone game data
Packager:       Davorin Učakar
Contact:        davorin.ucakar@gmail.com
Copyright:      See individual COPYING and README files
Licence:        See individual COPYING and README files
Description:    This package data for original OpenZone game: sky and terrain data, structures,
                graphical models and class definitions for object and fragments, sounds, music,
                scripts and translations for structures, objects and missions.
