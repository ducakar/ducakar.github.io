Soundsnap Licence
You are Free:

- To remix or transform the sounds in any way

- To copy, distribute and transmit the sounds

- To use the sounds in any music, film, video game, website etc. whether commercial or not, without paying royalties or other fees

You Cannot:

- Make commercial distribution of these sounds 'as they are'. For example, you cannot download and sell them as part of a CD library


********************************
http://www.soundsnap.com/licence
********************************