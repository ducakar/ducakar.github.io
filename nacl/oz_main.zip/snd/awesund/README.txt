AwesundFX1 Weapons by Awesund (awesund@home.com)
************************************************
9 New Weapon SFX for:

-Shotgun
-Pulse Rifle-secondary mode
-Spidermine
-Grenade Launcher
-Chaingun
-Asault Rifle
-Rocket launcher
-Sniper Rifle
-Magnum
*******************************************
Instructions: Just unzip to your SIN folder
*******************************************
ABOUT THE NEW SOUNDS
   I'm a sound designer by trade. These sounds I created for Sin are  mix-modified blends of authentic gun and other sounds while still trying to retain the same "fullness" that the origional sounds posessed. (since they were so well done).
******************************************* 
* The Chain-gun now sounds like a bullet feasting, powder-whore! Much better.  Now you can hear the chain... <G>.

* The Sniper Rifle..ahh my favorite..I wanted to give it a sound that would enhance/compliment the visual action of the dramatic head shot reaction so thoughtfully provided for us by the programers. And if ya didn't notice...there iS a Silencer on this rifle. I made that more noticable too. It is not your Deer or Elk Hunting Gun at all!  lol.  nOpE..This Sniper rifle is a precision-electro-automatic-reloading piece of engineering genius..and NOw it sounds like it, too!  =] 

* The Assault Rifle or mini machine gun now has more the sound of an actual gun of its make. Then given a bit of punch for an interesting wake up call to move yer ass! 

* The Rocket has a bit more of a sting to the launch and is not so FAT sounding any more. 

* The Magnum now has more of a.. . well.. a magnum sound. Remember Dirty Harry's magnum?  lol

* The Shotgun is a powerful weapon, it's just hard to aim. You'll really like this one.

* Ahh..the Pulse Rifle.. . No changes were made to the standard mode, but when you switch it to secondary mode, it looks like an electric shock wave so I decided to make it sound like one.

* The new Spidermine sound is an alternate version of exactly what it does. It latches to a surface, arms, then gives a "ready" signal. The latching now sounds like it'll stick anywhere ;>  Then a few added clicks, functional SFX, and the final "ready" sound.

* The new Grenade Launcher is pretty cool. Now less annoying and much more like a real morter firing. I also added the faint sound of the glowing projectile sparks as indicated by the nice graffics. Then I added a reload sound to fit the weapon.. . whEw!  
************************************************

Enjoy

Your feedback is welcome
Awesund@home.com

Please visit http://www.parodycentral.net

DISTRIBUTION INFO: Distribute this sound Pak to whomever u wish, but please include this text file and see that everything remains unedited and unchanged.