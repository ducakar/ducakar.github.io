Model Name              : droid
installation directory  : quake2/baseq2/players/droid
Author                  : III_Demon
Email Address           : III_Demon@yahoo.com
Web Page		: http://www.drazium.com/3d/

* Description *

Sounds for my Quake 2 battle droid - just unzip into the quake2/baseq2/players/droid directory.

* Thanx *

My brother (Kevin Good) for creating, and redchurch for cleaning up the files so they work

* Copyright / Permissions *

These sounds are original, not movie samples, so I guess they're (c) Kevin Good. I don't think he cares much tho. =]
